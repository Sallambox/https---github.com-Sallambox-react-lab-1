import React from 'react'

export class Skills  extends React.Component{
    render() {
        return (
            <div className="container bg-secondary text-white m-3 p-3">
                <div className="row flex-row bg--bs-gray-dark darkBackground">
                    <div class="justify-center">
                        <h2>skills</h2>
                    </div>
                    <div class="justify-center">
                        <p>
                            Cupidatat irure duis incididunt eu.Excepteur Lorem officia occaecat elit et qui magna ut pariatur deserunt nostrud dolore laboris.
                        </p>
                    </div>
                    <div class="row">
                        <div className="row flex-row col-6 ">
                            <p>hello</p>
                            <p>hello</p>
                            <p>hello</p>
                            <p>hello</p>
                        </div>
                        <div className="row flex-row col-6 ">
                            <p>hello2</p>
                            <p>hello2</p>
                            <p>hello2</p>
                            <p>hello2</p>
                        </div>
                    </div>

                </div>
            </div>
        )
    }
}